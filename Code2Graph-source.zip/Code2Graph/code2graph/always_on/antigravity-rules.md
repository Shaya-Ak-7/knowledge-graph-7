---
trigger: always_on
description: Consult the code2graph knowledge graph at code2graph-out/ for codebase and architecture questions.
---

## code2graph

This project has a code2graph knowledge graph at code2graph-out/.

Rules:
- For codebase or architecture questions, when `code2graph-out/graph.json` exists, first run `code2graph query "<question>"` (CLI) or `query_graph` (MCP). Use `code2graph path "<A>" "<B>"` / `shortest_path` for relationships and `code2graph explain "<concept>"` / `get_node` for focused concepts. These return a scoped subgraph, usually much smaller than `GRAPH_REPORT.md` or raw grep output.
- If code2graph-out/wiki/index.md exists, navigate it instead of reading raw files
- Read code2graph-out/GRAPH_REPORT.md only for broad architecture review or when query/path/explain do not surface enough context
- After modifying code files in this session, run `code2graph update .` to keep the graph current (AST-only, no API cost)
