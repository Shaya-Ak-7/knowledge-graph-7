"""Json_config extractor. Moved verbatim from code2graph/extract.py."""
from __future__ import annotations


from pathlib import Path
from code2graph.extractors.base import _file_stem, _make_id, _read_text
from code2graph.ids import normalize_id


_CONFIG_JSON_NAMES = frozenset({
    "package.json", "tsconfig.json", "jsconfig.json", "composer.json",
    "deno.json", "deno.jsonc", "bower.json", "manifest.json",
    "app.json", "now.json", "vercel.json", "angular.json", "nest-cli.json",
    "biome.json", "biome.jsonc", "renovate.json", ".babelrc", ".babelrc.json",
    ".eslintrc.json", ".prettierrc.json", ".prettierrc", "babel.config.json",
})

_CONFIG_JSON_KEYS = frozenset({
    "dependencies", "devDependencies", "peerDependencies",
    "optionalDependencies", "bundleDependencies", "bundledDependencies",
    "extends", "$schema", "compilerOptions",
})

# Root-level keys that only a JSON Schema *document* carries. A schema that
# defines anything needs somewhere to put the definitions, and the spec's own
# keywords for that are `$defs` (2020-12) and `definitions` (draft-07/04);
# `$id` names the schema itself. Combined with `$schema` these separate "this
# file IS a schema" from "this config POINTS AT a schema" -- the latter points
# $schema at its own tool's schema (biomejs.dev, docs.renovatebot.com, ...),
# never at the meta-schema, and never carries these markers.
_SCHEMA_DEFINITION_KEYS = frozenset({"$defs", "definitions", "$id"})


def _is_config_json(path: Path, obj_node, source: bytes) -> bool:
    """True if a .json file is a recognized config/manifest worth AST-extracting.

    Matches by filename first (cheap), then falls back to a top-level key probe
    so arbitrarily-named config files (e.g. ``api.tsconfig.json``,
    ``foo.eslintrc.json``) are still picked up. Returns False for data JSON so it
    is skipped by the structural pass (#1224).

    A JSON Schema is *not* a config manifest. `$schema` sits in the probe's key
    set because configs legitimately carry it, but it is also the defining marker
    of a schema -- so a schema document satisfied the probe and was walked in
    full, re-opening the keyword-node explosion #1224 closed (#2255). One 160 KB
    contract contributed 362 keyword nodes and ~12 schema-only communities. The
    filename branches above run first, so `biome.json`/`renovate.json`/
    `package.json` never depended on the probe; the probe only decides the fate
    of arbitrarily-named files, which is why narrowing it is low-risk.

    Documented boundary: a hand-written schema carrying `$schema` but no
    `$defs`/`definitions`/`$id` is still walked. Catching it would need a
    keyword-density heuristic, which would risk skipping a real config whose keys
    happen to overlap schema vocabulary -- the worse error, since it drops
    structure silently (#1224). Pinned by
    ``tests/test_json_schema_config.py::test_minimal_schema_without_defs_or_id_is_still_walked``.
    """
    name = path.name.casefold()
    if name in _CONFIG_JSON_NAMES:
        return True
    # Common compound config names: *.eslintrc.json, *.prettierrc.json, etc.
    if name.endswith((".eslintrc.json", ".prettierrc.json", ".babelrc.json",
                      "tsconfig.json", "jsconfig.json")):
        return True
    # Collect the root object's immediate keys once (no deep walk), so the
    # schema check below and the config probe agree on the same key set.
    root_keys: set[str] = set()
    for top_key in obj_node.children:
        if top_key.type != "pair":
            continue
        key_node = top_key.child_by_field_name("key")
        if key_node is None:
            continue
        kc = key_node.child_by_field_name("string_content")
        root_keys.add(_read_text(kc, source) if kc
                      else _read_text(key_node, source).strip('"\''))
    # A file that declares the meta-schema AND defines something IS a schema.
    if "$schema" in root_keys and (root_keys & _SCHEMA_DEFINITION_KEYS):
        return False
    # Top-level key probe. `$ref` is deliberately absent: a root-level `$ref` is
    # a schema construct and never a config signal (#2255).
    if root_keys & _CONFIG_JSON_KEYS:
        return True
    return False

def extract_json(path: Path) -> dict:
    """Extract structure and dependency edges from a *config/manifest* .json file.

    Data-shaped JSON (eval fixtures, datasets, GeoJSON, API response dumps) is
    deliberately skipped — AST-walking it produced hundreds of orphan key-nodes
    and duplicate communities that swamped real structure (#1224). JSON Schema
    documents are skipped for the same reason (#2255). Recognition is by filename
    (package.json, tsconfig.json, …) or a top-level key probe (dependencies /
    extends / $schema / compilerOptions)."""
    _JSON_MAX_BYTES = 1_048_576  # 1 MiB — skip large fixture dumps / GeoJSON blobs

    try:
        import tree_sitter_json as tsjson
        from tree_sitter import Language, Parser
    except ImportError:
        return {"nodes": [], "edges": [], "error": "tree-sitter-json not installed"}

    try:
        # Bounded read instead of stat()+read() to eliminate TOCTOU (J-1):
        # read one byte beyond the limit so we can detect oversized files even
        # if the file grows between stat and read.
        with path.open("rb") as _f:
            source = _f.read(_JSON_MAX_BYTES + 1)
        if len(source) > _JSON_MAX_BYTES:
            return {"nodes": [], "edges": [], "error": "json file too large to index"}
        language = Language(tsjson.language())
        parser = Parser(language)
        tree = parser.parse(source)
        root = tree.root_node
    except Exception as e:
        return {"nodes": [], "edges": [], "error": str(e)}

    stem = _file_stem(path)
    str_path = str(path)
    nodes: list[dict] = []
    edges: list[dict] = []
    seen_ids: set[str] = set()

    # Keys whose string values become imports (package.json dep blocks)
    _DEP_KEYS = frozenset({
        "dependencies", "devDependencies", "peerDependencies",
        "optionalDependencies", "bundleDependencies", "bundledDependencies",
    })

    def add_node(nid: str, label: str, line: int, file_type: str = "code") -> None:
        if nid and nid not in seen_ids:
            seen_ids.add(nid)
            nodes.append({"id": nid, "label": label, "file_type": file_type,
                          "source_file": str_path, "source_location": f"L{line}"})

    def add_edge(src: str, tgt: str, relation: str, line: int,
                 context: str | None = None) -> None:
        if not src or not tgt or src == tgt:
            return
        edge = {"source": src, "target": tgt, "relation": relation,
                "confidence": "EXTRACTED", "source_file": str_path,
                "source_location": f"L{line}", "weight": 1.0}
        if context:
            edge["context"] = context
        edges.append(edge)

    file_nid = _make_id(str(path))
    add_node(file_nid, path.name, 1)

    def _key_text(pair_node) -> str | None:
        """Extract the string content of a pair's key."""
        key_node = pair_node.child_by_field_name("key")
        if key_node is None:
            return None
        if key_node.type == "string":
            content = key_node.child_by_field_name("string_content")
            if content:
                return _read_text(content, source)
            # fallback: strip surrounding quotes
            raw = _read_text(key_node, source)
            return raw.strip('"\'')
        return _read_text(key_node, source)

    def _val_node(pair_node):
        return pair_node.child_by_field_name("value")

    def walk_object(obj_node, parent_nid: str, parent_key: str | None,
                    depth: int, pair_count: list) -> None:
        if depth > 6:
            return
        for child in obj_node.children:
            if child.type != "pair":
                continue
            if pair_count[0] >= 500:  # check per-pair so the cap is honoured exactly (J-3)
                return
            pair_count[0] += 1
            key = _key_text(child)
            if not key:
                continue
            # A key that normalizes to nothing (a JSONC `"//"` comment key, say)
            # would collapse `_make_id(stem, key)` down to the bare file-stem id,
            # which is absolute-path-derived and leaks the scan path (#1899). Such
            # keys carry no graph signal, so drop them.
            if not normalize_id(key):
                continue
            key_nid = _make_id(stem, *(([parent_key] if parent_key else []) + [key]))
            if not key_nid:
                continue
            line = child.start_point[0] + 1
            add_node(key_nid, key, line)
            add_edge(parent_nid, key_nid, "contains", line)

            val = _val_node(child)
            if val is None:
                continue

            if val.type == "object":
                walk_object(val, key_nid, key, depth + 1, pair_count)

            elif val.type == "array" and key == "extends":
                # Only a genuine `extends` array (tsconfig 5.0+, eslint) is
                # inheritance. This branch used to fire for *every* array under
                # a tracked key, so `compilerOptions.lib: ["dom","esnext"]` and
                # `exclude: ["node_modules",".next"]` each emitted an `extends`
                # edge — array membership relabelled as inheritance. The string
                # branch below already gates on `key == "extends"`; this matches
                # it. Non-`extends` arrays keep their `contains` edge only.
                # Prefix with "ref_" so external refs don't collide with real
                # code/file node IDs that share the same collapsed _make_id (J-4).
                for item in val.children:
                    if item.type == "string":
                        content = item.child_by_field_name("string_content")
                        ref = _read_text(content, source) if content else _read_text(item, source).strip('"\'')
                        if ref:
                            ref_nid = _make_id("ref", ref)
                            if ref_nid:
                                add_node(ref_nid, ref, line, file_type="concept")
                                add_edge(key_nid, ref_nid, "extends", line, context="import")

            elif val.type == "string":
                content = val.child_by_field_name("string_content")
                val_text = _read_text(content, source) if content else _read_text(val, source).strip('"\'')

                if key == "extends" and val_text:
                    # Namespace external refs to avoid ID collision with file nodes (J-4)
                    ref_nid = _make_id("ref", val_text)
                    if ref_nid:
                        add_node(ref_nid, val_text, line, file_type="concept")
                        add_edge(file_nid, ref_nid, "extends", line, context="import")

                elif key == "$ref" and val_text:
                    # Namespace $ref values to prevent edge hijacking into code nodes (J-4)
                    ref_nid = _make_id("ref", val_text)
                    if ref_nid:
                        add_edge(parent_nid, ref_nid, "references", line)

                elif parent_key in _DEP_KEYS and val_text:
                    # Two defects fixed here, both from the #1764 shape:
                    #
                    # 1. The edge ran `key_nid -> dep_nid`, and both nodes carry
                    #    the *same label* (the dependency name), so every
                    #    dependency produced a visually self-referential
                    #    `react --imports--> react` (22 of them on a mid-size
                    #    Next.js repo). The self-loop guard in
                    #    test_extract_json_import_and_extends_targets_are_real_nodes
                    #    compares node ids, and these two ids differ, so the
                    #    duplicate slipped past it. Sourcing the edge at the
                    #    manifest yields `package.json --imports--> react`.
                    #
                    # 2. `_make_id(key)` minted a *bare* id, skipping the "ref"
                    #    namespacing every other external reference in this file
                    #    applies (J-4). A dependency named `utils`, `colors` or
                    #    `types` could then be collapsed onto a same-named local
                    #    module by build.py's alias index -- the #1638 failure
                    #    mode reached through a different door.
                    dep_nid = _make_id("ref", key)
                    if dep_nid:
                        add_node(dep_nid, key, line, file_type="concept")
                        add_edge(file_nid, dep_nid, "imports", line, context="import")

    # Entry: find root document → object
    doc = root
    if doc.type == "document" and doc.child_count > 0:
        doc = doc.children[0]
    if doc.type == "object":
        # Only AST-extract recognized config/manifest JSON. Data JSON (fixtures,
        # datasets, GeoJSON, API dumps) is skipped so it doesn't explode into
        # orphan key-nodes (#1224); it's left to the LLM semantic pass.
        if not _is_config_json(path, doc, source):
            return {"nodes": [], "edges": [], "skipped": "data json (not a config/manifest)"}
        walk_object(doc, file_nid, None, 0, [0])
    else:
        # Top-level array or scalar => data JSON, never a config/manifest.
        return {"nodes": [], "edges": [], "skipped": "data json (non-object root)"}

    return {"nodes": nodes, "edges": edges}
