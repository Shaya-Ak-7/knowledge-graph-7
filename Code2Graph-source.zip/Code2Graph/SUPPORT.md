# Getting help

Code2Graph is an experimental project whose name is provisional. For help:

- **Usage questions and ideas:** open a [GitHub Discussion](https://github.com/Shaya-Ak-7/knowledge-graph-7/discussions) or issue.
- **Bug reports:** use the [issue tracker](https://github.com/Shaya-Ak-7/knowledge-graph-7/issues). Include the command, expected and actual behavior, Python version, operating system, and a minimal reproduction.
- **Security concerns:** do not open a public issue. Follow the instructions in [SECURITY.md](SECURITY.md) and the repository's [security policy](https://github.com/Shaya-Ak-7/knowledge-graph-7/security/policy).
- **Contributing:** see [CONTRIBUTING.md](CONTRIBUTING.md).

The repository's current documentation is in `README.md`, `ARCHITECTURE.md`, and `docs/`.
