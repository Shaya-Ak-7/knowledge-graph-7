# Release policy

Code2Graph is a temporary project name and the package's final distribution name, ownership, and release plan have not been established. **Do not publish this package to a public package index or create a release yet.**

Before enabling releases, maintainers must choose the final project/package name, confirm ownership of that name, establish versioning and provenance policy, update the project URLs and package metadata, and configure a trusted publisher for the repository. Release automation should be added only after those decisions are complete.

For local development, install directly from the checkout:

```bash
python -m pip install -e '.[mcp]'
```
