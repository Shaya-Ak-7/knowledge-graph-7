## code2graph

This project has a code2graph knowledge graph at code2graph-out/.

Rules:
- When working on Code2Graph itself, use the repository's existing Code2Graph guidance. For codebase questions, prefer scoped graph queries where available; use the report for broad orientation. Do not use the graph as evidence when the task concerns the graph's correctness itself.
- If code2graph-out/wiki/index.md exists, navigate it instead of reading raw files
- After modifying code files in this session, run `code2graph update .` to keep the graph current (AST-only, no API cost)
